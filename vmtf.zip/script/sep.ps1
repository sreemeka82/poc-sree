$pathvargs = {C:\Temp\sep\setup.exe /S /v/qn }
Invoke-Command -ScriptBlock $pathvargs
