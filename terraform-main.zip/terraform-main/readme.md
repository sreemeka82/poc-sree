create the own vpc module
call from other environment 
